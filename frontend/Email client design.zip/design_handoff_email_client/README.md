# Handoff: Keyboard-First Email Client (Desktop)

## Overview
A desktop email client aimed at **developers** — keyboard-first, calm, and minimal, with smart organization (bundles/labels, snooze). Dark "console" base with an airy sidebar and a single purple accent. The prototype covers four core screens of the primary loop: **Inbox**, **Thread (detail + reply)**, **Compose**, and **Search**.

The defining ideas to preserve:
- **Keyboard-first vocabulary** surfaced everywhere — a vim-style status bar, shortcut hints next to actions, a `⌘K` search affordance, and a `~/mail/<screen>` path label.
- **Calm monochrome** — dark neutrals with a single purple accent. No saturated icon blocks, no emoji. Actions are rendered as **monospace text "ghost" buttons**, not icon glyphs. This is intentional; do not reintroduce icon fonts/emoji for primary actions.
- **Two-typeface system** — monospace for "chrome" (paths, labels, shortcuts, tags, metadata) and a humanist sans for human content (sender names, subjects, body copy).

## About the Design Files
The file in this bundle (`Inbox.dc.html`) is a **design reference created in HTML** — a prototype showing the intended look and behavior. It is **not production code to copy directly**. It is authored as a "Design Component" (a streaming HTML format with a small template + logic class); the markup uses custom tags like `<sc-for>`/`<sc-if>` and inline styles, which are *prototyping conveniences*, not a target architecture.

**The task:** recreate these designs in the target codebase's existing environment (React, Vue, Svelte, SwiftUI, etc.) using its established patterns, component primitives, and styling solution. If no environment exists yet, choose the most appropriate framework for the project and implement there. Treat the HTML as the source of truth for **visual design and behavior**, and translate the data model / state described below into idiomatic components.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interaction intent are specified. Recreate the UI faithfully using the codebase's existing libraries and patterns. Exact hex values, font sizes, and measurements are listed under **Design Tokens** and per-component below.

---

## Global Layout

A single full-viewport (`100vw × 100vh`) app shell, `display:flex; flex-direction:column`:

1. **Top bar** — `height:54px`, fixed. Left: window "traffic-light" dots + `~/mail/<screen>` path label (the `<screen>` word is in the accent color). Center: **segmented screen switcher** (Inbox · Thread · Compose · Search). Right: a search field affordance (`⌘K`) + primary **Compose** button.
2. **Body** — `flex:1`, `display:flex`. Left: **persistent sidebar** (`width:248px`). Right: **main area** (`flex:1`) that swaps between the four screens.
3. **Status bar** — `height:32px`, fixed at the bottom, full width. Vim-style: a colored mode badge (`NORMAL` / `THREAD` / `COMPOSE` / `SEARCH`) + contextual keyboard hints + a right-aligned counter.

Backgrounds: app base `#0E0E13`; chrome panels (top bar, sidebar, status bar) `#0B0B10`; inset fields/cards `#15151C`. Hairline dividers `#1A1A22`; row dividers `#15151D`; borders on controls `#23232E`.

### Top bar — details
- Traffic-light dots: three `11×11` circles, `border-radius:50%`, `#2A2A36`, `gap:7px`.
- Path label: monospace `13px`, `#5A5A66`; the active screen word is colored with the **accent** (default `#8B7CF6`).
- **Segmented switcher**: container `background:#15151C; border:1px solid #23232E; border-radius:9px; padding:3px`. Each segment: monospace `12px`, `padding:6px 14px`, `border-radius:6px`. Active segment → `background: accent@13% alpha`, `color: accent`. Inactive → `color:#8A8A96`, transparent. Four segments: Inbox, Thread, Compose, Search.
- Search affordance (right): `background:#15151C; border:1px solid #23232E; border-radius:9px; padding:8px 13px; width:240px`. Leading `⌕`, label "Search mail" `#6A6A76` `13px`, trailing mono `⌘K` `#5A5A66`. Click → Search screen.
- **Compose button**: `background: accent; color:#0E0E13; border-radius:9px; padding:9px 16px; font-size:13px; font-weight:600`. Label "Compose" + dim mono key `c`. Click → Compose screen.

### Sidebar — details (persistent across all screens)
- `width:248px; padding:22px 16px; border-right:1px solid #1A1A22; background:#0B0B10; font-size:13.5px`.
- **Primary nav items** (Inbox, Snoozed, Done, Sent, Drafts): each `padding:10px 13px; border-radius:10px; gap:11px`. The **active** item (Inbox when on the Inbox screen) → `background: accent@13%`, `color: accent`, `font-weight:600`. Inactive → `color:#8A8A96`.
- Count badges: monospace `11.5px`. The active item's badge is a solid pill `background: accent; color:#0E0E13; border-radius:20px; padding:1px 8px`. Other counts are plain `#5A5A66`.
- **"Bundles" section** header: `11px`, uppercase, `letter-spacing:0.09em`, `#4A4A55`, `padding:22px 13px 10px`.
- Bundle items (GitHub, Deploys, Alerts, Team, Receipts): `padding:9px 13px; gap:12px`, label `#8A8A96`, trailing count mono `11px` `#5A5A66`. Each has an `8×8` rounded color swatch (`border-radius:50%`):
  - GitHub `#6E59C7` · Deploys `#5566C9` · Alerts `#C0694F` · Team `#5E54C0` · Receipts `#5B8A6F`.

### Status bar — details
- `height:32px; padding:0 22px; background:#0B0B10; border-top:1px solid #1A1A22`, monospace `11px`, `#5A5A66`.
- Mode badge: `background: accent; color:#0E0E13; border-radius:5px; padding:2px 9px; font-weight:600`.
- Hints (color `#8A8A96`) per screen:
  - Inbox / `NORMAL`: `j k move · e archive · s snooze · c compose · ⌘K palette`
  - Thread / `THREAD`: `r reply · a reply all · f forward · e archive · esc back`
  - Compose / `COMPOSE`: `⌘↵ send · ⌘⇧A attach · esc discard`
  - Search / `SEARCH`: `↑↓ navigate · ↵ open · esc clear`
- Right-aligned counter: `<unreadCount> unread · 7 done today` (`#8A8A96`).

---

## Screens / Views

### 1. Inbox (`screen = 'inbox'`)
**Purpose:** Triage the conversation list quickly via keyboard.

**Layout:** Main area is a column: a `50px` list header, then a scrolling list grouped into **Today** and **Earlier** sections.
- List header: left `"<total> conversations"` (`#C9C9D4`, `600`) `·` `"<unread> unread"` (accent); right monospace `"sort: newest ↓"` (`#5A5A66`). `padding:0 26px; border-bottom:1px solid #1A1A22`.
- Section labels ("Today" / "Earlier"): `11px` uppercase `letter-spacing:0.09em` `#4A4A55`, `padding:18px 26px 8px`.

**Email row** (`display:flex; align-items:center; gap:15px; padding:14px 26px; border-bottom:1px solid #15151D; cursor:pointer`). Clicking a row opens the **Thread** screen. Columns, left→right:
1. **Status dot** — `8×8` circle, `flex:none`. Alert → `#C0694F`; unread → accent; read → transparent.
2. **Sender** — fixed `width:160px`, `14px`, truncated. Unread → `#D6D0F0` `weight 600`; read → `#8A8A96` `weight 400`.
3. **Subject + preview** — `flex:1`, truncated single line. Subject: `14px`, unread `#ECEAF6`/`600`, read `#9A9AA6`/`400`. Preview (when shown): inline, `#5E5E6A`, `13.5px`, prefixed by two spaces. Toggle via `showPreview` (see Tweaks).
4. **Tag chip** — monospace `10.5px`, `border-radius:6px; padding:3px 9px`. Color by label (see Tag palette).
5. **Time** — fixed `width:60px`, right-aligned, monospace `11.5px`, `#5A5A66`.

**Selected row** (first row by default): `background: accent@10%`, `border-left:2px solid accent`.

### 2. Thread (`screen = 'thread'`)
**Purpose:** Read a conversation and reply inline. Opened by clicking any inbox row or search result, or the Thread segment.

**Layout:** column — a thread header (`flex:none`), a scrolling messages area (`flex:1`), and a pinned reply composer (`flex:none`) at the bottom.

**Thread header** (`padding:13px 26px; border-bottom:1px solid #1A1A22; gap:14px`):
- **Back button**: monospace `12px` `← esc`, ghost-button style (`border:1px solid #23232E; border-radius:7px; padding:6px 11px; color:#8A8A96`). Click → Inbox.
- Title block: subject `15.5px` `600` `#ECEAF6` (truncated); subtitle `12px` `#6A6A76` → `"3 messages · Marina Chen, you, Sam Okonkwo"`.
- Right actions (`margin-left:auto; gap:7px`): a **Team** tag chip, then **ghost text buttons**: `Star`, `Archive` (+ dim key `e`), `Snooze` (+ dim key `s`), and a `···` overflow. Ghost-button style: monospace `11px`, `color:#8A8A96`, `border:1px solid #23232E`, `border-radius:7px`, `padding:6px 11px`, hover `background:#15151C`. Dim shortcut keys are `#5A5A66`. **No icon glyphs/emoji** — this is deliberate.

**Message** (`display:flex; gap:14px; padding:20px 0; border-bottom:1px solid #15151D`):
- **Avatar**: `34×34`, `border-radius:9px`, `background:#15151C`, `border:1px solid #23232E`, monospace initials `11px` `#9A9AA6`. Monochrome by design (no colored fills).
- Body column (`flex:1`):
  - Header line: name `14px` `600` `#E8E8EF`; email `12px` `#5A5A66`; right-aligned timestamp monospace `11px` `#5A5A66`.
  - **Collapsed** messages show a one-line snippet `13.5px` `#6A6A76` (truncated), `cursor:pointer` to expand.
  - **Expanded** messages show full body paragraphs: `14px`, `line-height:1.72`, `#CFCFDB`, `margin:0 0 13px`.
- In the prototype the latest message is expanded; the two earlier ones are collapsed.

**Reply composer** (pinned bottom, `border-top:1px solid #1A1A22; background:#0B0B10; padding:16px 26px`):
- Mode row: `Reply` (active: mono `11.5px`, `background: accent@13%`, `color: accent`, `border-radius:6px; padding:5px 12px`), `Reply all`, `Forward` (inactive `#8A8A96`). Right: mono `"to Marina Chen"` `#5A5A66`.
- Input card: `background:#15151C; border:1px solid #23232E; border-radius:11px; padding:14px 16px`. Textarea `min-height:70px`, transparent, `14px`, `#E8E8EF`, placeholder `"Write your reply…  (⌘↵ to send)"` (placeholder color `#4A4A55`).
- Footer row: **Send** button (`background: accent; color:#0E0E13; border-radius:8px; padding:8px 16px; font-size:13px; 600` + dim mono `⌘↵`), then a formatting group of `28×28` ghost squares (`B`, `I`, `</>` — monospace, `color:#8A8A96`, `border-radius:7px`, hover `background:#15151C`), an `Attach` ghost button, and a right-aligned mono `"draft saved"` `#5A5A66`.

### 3. Compose (`screen = 'compose'`)
**Purpose:** Write a new message in a focused, centered surface.

**Layout:** main area scrolls and centers a compose card (`max-width:840px; width:100%`). Card: `background:#0B0B10; border:1px solid #1F1F29; border-radius:14px`.
- **Card header**: `padding:16px 22px; border-bottom:1px solid #1A1A22`. Left "New message" `15px` `600` `#E8E8EF`; right mono `"esc to discard"` `11px` `#5A5A66`.
- **To row** (`padding:13px 22px; border-bottom:1px solid #1A1A22; gap:14px`): mono label `to` (`12px` `#5A5A66`, `width:56px`); a recipient chip "Marina Chen ✕" (`background: accent@13%; color: accent; border-radius:7px; padding:4px 10px; 13px`); a transparent input (placeholder "Add recipients…"); right mono `"cc bcc"`.
- **Subject row** (same frame): mono label `subject`; input prefilled `"Re: API rate limiting design"`, `14px` `600` `#E8E8EF`.
- **Body**: full-width textarea, `min-height:300px`, `14.5px`, `line-height:1.75`, `#D6D6E0`, `padding:20px 22px`. Prefilled with a multi-paragraph draft (see prototype for copy).
- **Footer** (`padding:14px 22px; border-top:1px solid #1A1A22; gap:10px`): **Send** button (`border-radius:9px; padding:9px 18px; 13.5px; 600` + dim `⌘↵`), formatting group of `28×28` ghost squares (`B`, `I`, `</>`, `link`), an `Attach` ghost button, right-aligned mono `"draft saved · 12s ago"`, and a `Discard` ghost button.

### 4. Search (`screen = 'search'`)
**Purpose:** Query mail with operator syntax, keyboard-driven.

**Layout:** main area is a column: a search header block, a `42px` results meta bar, then a scrolling results list (reuses the inbox **email row**).
- **Search input block** (`padding:22px 26px 14px; border-bottom:1px solid #1A1A22`): an input row `background:#15151C; border:1px solid accent; border-radius:11px; padding:13px 17px; gap:13px`. Leading `⌕` in accent `17px`; input `16px` `#E8E8EF`; trailing mono `esc`. The input is **bound to query state** (`onInput` updates results live).
  - Below: a filters row. Leading mono `"filters:"` `#4A4A55`. **Active query tokens** render as chips (mono `11.5px`, `background: accent@13%`, `color: accent`, `border-radius:7px; padding:4px 10px`, each with a dim `✕`). Then **suggestion chips** (`label:`, `has:attachment`, `after:2026-06-01`) as dashed ghosts (`border:1px dashed #2A2A36; color:#5A5A66`).
- **Results meta bar** (`height:42px; padding:0 26px; border-bottom:1px solid #1A1A22`): left `"<n> results"` (number in accent `600`); right mono `"↑↓ navigate · ↵ open"`.
- **Results list**: same email-row component as Inbox; first result is shown as selected. Clicking a result opens the Thread.
- **Empty state**: centered mono `13px` `#5A5A66` → `"no matches for this query"`, `padding:60px 26px`.

---

## Tag / Label Palette
Tag chips use a calm, low-chroma palette on dark (`background` is a translucent fill, `color` is a light tint):
- **GitHub** — bg `rgba(110,89,199,0.16)`, fg `#B6A6F7`
- **Deploys** — bg `rgba(85,102,201,0.16)`, fg `#9FB0F0`
- **Alerts** — bg `rgba(192,105,79,0.18)`, fg `#E0A18F` (the one warm accent, reserved for alerts)
- **Team** — bg `rgba(94,84,192,0.16)`, fg `#B0A6F0`
- **Receipts** — bg `rgba(63,122,92,0.18)`, fg `#8FCAA6`
- **Reads** — bg `rgba(120,114,130,0.18)`, fg `#A8A2B2`

---

## Interactions & Behavior
- **Screen navigation**: segmented switcher selects a screen. Compose button → Compose. Search field → Search. Any inbox row or search result → Thread. Thread back button (`← esc`) → Inbox. (In a real build, wire the documented keyboard shortcuts: `c` compose, `⌘K` / `/` search, `e` archive, `s` snooze, `r` reply, `esc` back/close, `j`/`k` move selection, `↵` open.)
- **Search filtering** (live, on each keystroke). Tokenize the query on whitespace; a message matches only if **every** token matches:
  - `from:<text>` → sender name contains `<text>`
  - `label:<text>` → tag contains `<text>`
  - `is:unread` / `is:read` → unread flag
  - `has:…`, `after:…`, `before:…` → accepted as no-ops in the prototype (implement against real data)
  - any other bare word → substring match across `from + subject + preview + tag`
  - Default seeded query: `from:github is:unread` (yields the two unread GitHub items).
- **Hover states**: ghost buttons and formatting squares get `background:#15151C` on hover. Rows are `cursor:pointer`.
- **Load animation**: app shell fades/translates up once on mount (`fadeUp`, `0.45s ease`). Keep subtle or drop per your motion system.
- **Selection**: first item in a list is the visually "selected" row (accent left border + accent@10% background). In a real build this should track keyboard focus (`j`/`k`).

## State Management
- `screen`: `'inbox' | 'thread' | 'compose' | 'search'` — which view is mounted in the main area. Sidebar, top bar, and status bar persist; only the main area swaps.
- `query`: string — the live search query; drives the filtered results and the parsed filter chips.
- Derived per render: filtered/grouped inbox lists (Today = first 5, Earlier = rest), unread count, search results + parsed chips, active-segment styling, and the status-bar mode/hints for the current screen.
- Email record shape used throughout: `{ from, subject, preview, time, tag, unread?, alert?, selected? }`. Thread message shape: `{ initial, name, email, time, expanded, snippet?, paragraphs? }`.

## Design Tokens
**Colors**
- App base `#0E0E13` · chrome panels `#0B0B10` · inset fields/cards `#15151C` · compose card border `#1F1F29`
- Dividers: hairline `#1A1A22` · row `#15151D` · control border `#23232E` · dashed ghost `#2A2A36`
- Text: primary `#E8E8EF` / `#ECEAF6` · sender-unread `#D6D0F0` · body `#CFCFDB` · secondary `#9A9AA6` / `#8A8A96` · tertiary `#6A6A76` · muted `#5A5A66` · faint `#4A4A55`
- Accent (purple, tweakable): default `#8B7CF6`; alternates `#A78BFA`, `#7C6CF0`, `#9B6CF0`, `#B07CF6`. Derived: `accent@13%` for active fills, `accent@10%` for selected rows. On-accent text/icons use `#0E0E13`.
- Alert/warm: `#C0694F` (dot), `#E0A18F` (tag fg)
- Bundle swatches: GitHub `#6E59C7` · Deploys `#5566C9` · Alerts `#C0694F` · Team `#5E54C0` · Receipts `#5B8A6F`

**Typography**
- Mono (chrome): **JetBrains Mono** — paths, labels, shortcuts, tags, counts, metadata, timestamps, ghost buttons. Sizes `10.5–13px`.
- Sans (content): **Hanken Grotesk** — sender names, subjects, message bodies, button labels. Sizes `12–16px`; body `line-height ~1.72`.
- Weights used: 400, 500, 600 (700 only for the formatting `B` glyph).

**Radius**: `5px` (mode badge) · `6px` (chips, segments) · `7px` (ghost buttons/squares) · `8–9px` (buttons, fields) · `10px` (sidebar items) · `11px` (search/reply cards) · `14px` (compose card) · `50%` (dots/traffic lights).

**Spacing**: app paddings `26px` (list gutters), `22px` (compose card), `16px` (sidebar/status); row padding `14px 26px`; common gaps `7–15px`.

**Shadows**: none in the dark UI — depth comes from background steps and hairline borders. (The earlier exploration canvas used soft drop shadows on light frames; not used here.)

**Motion**: `fadeUp` entrance `0.45s ease`; hover transitions can be ~`120ms`.

## Tweakable Props (carried on the root component)
- `accent` (color) — the single accent hue. Default `#8B7CF6`; curated alternates listed above. Drives active states, dots, primary buttons, mode badge, selection.
- `showPreview` (boolean, default `true`) — show/hide the inline preview snippet in list rows.
- `unreadOnly` (boolean, default `false`) — filter the inbox to unread only (collapses into a single group).

## Assets
None. There are no raster images or icon assets — all "icons" are monospace text or simple CSS shapes (circles/rounded squares). Fonts load from Google Fonts (JetBrains Mono, Hanken Grotesk); swap for self-hosted/licensed equivalents in production if needed.

## Files
- `Inbox.dc.html` — the full prototype (all four screens, switcher, and search logic). Open it in a browser to see live behavior; read its template + logic class for exact values and the seeded sample data (GitHub, Vercel, CI, Linear, Sentry, Marina Chen, npm, Stripe, AWS, TLDR).
